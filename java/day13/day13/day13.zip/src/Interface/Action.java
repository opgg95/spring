package Interface;

public interface Action {

	// 줍다
	public void pickup();
}
