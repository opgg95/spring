package Interface;

public interface Move {

	//걷다
	public void walk();
	
	// 뛰다
	public void run();
	
	// 점프
	public void jump();
	
}
