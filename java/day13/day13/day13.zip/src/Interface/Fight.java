package Interface;

public interface Fight {

	// 공격
	public void attack();
	
	// 방어
	public void shield();
}
