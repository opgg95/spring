package Interface;

public class User implements Unit {

	/*
	 * 다음과 같이 메서드 재정의가 이루어지면 필요한 기능을 구현한다.
	 */
	@Override
	public void attack() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void shield() {
		// TODO Auto-generated method stub
		
	}

}
