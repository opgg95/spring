package test1;

public class Main03 {

	public static void main(String[] args) {
		/*
		 * 	-	int형 변수 x가 10보다 크고 20보다 작을 때 true인 조건식
		 *		: 10 < x && x < 20		
		 * 
			-	int형 변수 year가 400으로 나눠떨어지거나 또는 4로 나눠떨어지고 
				100으로 나눠떨어지지 않을 때 true인 조건식
				: year % 400 == 0 || year % 4 == 0 && year % 100 != 0
				
			-	boolean형 변수 powerOn이 false일 때 true인 조건
				: powerOn == false
				: !powerOn
		 */
		
		
	}

}
